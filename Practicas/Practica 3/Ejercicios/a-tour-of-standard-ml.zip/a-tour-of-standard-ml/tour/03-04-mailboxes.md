---
chapter: Concurrent ML
title: Mailboxes
index: 3
section: 4
---
In a previous section we used synchronous channels, but CML provides asynchronous channels with a nonblocking `send`, called Mailboxes.
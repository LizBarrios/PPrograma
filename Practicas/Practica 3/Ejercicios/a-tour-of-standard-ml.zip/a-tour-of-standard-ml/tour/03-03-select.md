---
chapter: Concurrent ML
title: Select
index: 3
section: 3
---
`select` lets a thread wait on a list of communication events.

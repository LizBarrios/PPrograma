---
chapter: Basics
title: Functors
index: 1
section: 9
---

Modules may accept other modules as parameters, including accepting a signature rather than a specific implementation. These are called functors, and declared using the `functor` keyword.
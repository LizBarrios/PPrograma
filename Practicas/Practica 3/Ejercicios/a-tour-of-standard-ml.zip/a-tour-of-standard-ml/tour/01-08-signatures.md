---
chapter: Basics
title: Signatures, continued
index: 1
section: 8
---
Signatures do not necessarily need to be tied to a specific module. A signature may be defined separately, and have multiple implementations.
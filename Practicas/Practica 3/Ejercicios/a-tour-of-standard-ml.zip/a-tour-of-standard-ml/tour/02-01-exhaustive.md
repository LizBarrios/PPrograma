---
chapter: Working in Standard ML
title: Exhaustivity checking
index: 2
section: 1
---
Pattern matching provides exhaustivity checking for data type cases. If you miss a case, the compiler will emit a warning. Compiler options may elevate this to an error.
---
chapter: Working in Standard ML
title: Pattern matching in functions
index: 2
section: 3
---
All of these together makes it easy to express your problem as a set of cases, which you can then decompose and compose to write your logic.
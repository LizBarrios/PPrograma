---
chapter: Basics
title: Basic data types
index: 1
section: 2
---

Standard ML has six data types built in: `unit`, `bool`, `int`, `real`, `string`, and `char`.
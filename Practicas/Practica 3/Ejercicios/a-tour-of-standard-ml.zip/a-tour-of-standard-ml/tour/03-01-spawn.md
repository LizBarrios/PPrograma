---
chapter: Concurrent ML
title: Spawning a light-weight thread
index: 3
section: 1
---
`spawn` creates a lightweight thread managed by the Concurrent ML runtime.
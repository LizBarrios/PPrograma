---
chapter: Working in Standard ML
title: Conditional expressions
index: 2
section: 4
---
Standard ML defines one conditional expression. You may define additional cases by chaining the if-else expressions.

Note that all branches of the if-else expression must have the same type.